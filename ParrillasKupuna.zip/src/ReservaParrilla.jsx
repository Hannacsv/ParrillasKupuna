import { useState } from "react";

export default function ReservaParrilla() {
  const [reservas, setReservas] = useState([]);
  const [nuevaReserva, setNuevaReserva] = useState({
    nombre: "",
    villa: "Nalu",
    fecha: "",
    horaInicio: "",
    horaFin: "",
  });

  const villas = ["Nalu", "Ohana", "Kai"];

  const handleReserva = () => {
    const conflicto = reservas.find((r) => {
      return (
        r.fecha === nuevaReserva.fecha &&
        ((nuevaReserva.horaInicio >= r.horaInicio && nuevaReserva.horaInicio < r.horaFin) ||
          (nuevaReserva.horaFin > r.horaInicio && nuevaReserva.horaFin <= r.horaFin) ||
          (nuevaReserva.horaInicio <= r.horaInicio && nuevaReserva.horaFin >= r.horaFin))
      );
    });

    if (conflicto) {
      alert("Ya hay una reserva en ese horario. Por favor elige otro.");
      return;
    }

    setReservas([...reservas, nuevaReserva]);
    setNuevaReserva({ nombre: "", villa: "Nalu", fecha: "", horaInicio: "", horaFin: "" });
  };

  return (
    <div style={{ maxWidth: "600px", margin: "auto", padding: "20px" }}>
      <h1 style={{ fontSize: "2rem", marginBottom: "1rem" }}>Reserva Zona de Parrilla</h1>

      <div style={{ background: "#fff", padding: "1rem", borderRadius: "8px", marginBottom: "2rem" }}>
        <div>
          <label>Nombre del Huésped</label>
          <input
            type="text"
            value={nuevaReserva.nombre}
            onChange={(e) => setNuevaReserva({ ...nuevaReserva, nombre: e.target.value })}
            placeholder="Tu nombre"
            style={{ width: "100%", padding: "8px", marginBottom: "1rem" }}
          />
        </div>

        <div>
          <label>Villa</label>
          <select
            value={nuevaReserva.villa}
            onChange={(e) => setNuevaReserva({ ...nuevaReserva, villa: e.target.value })}
            style={{ width: "100%", padding: "8px", marginBottom: "1rem" }}
          >
            {villas.map((villa) => (
              <option key={villa}>{villa}</option>
            ))}
          </select>
        </div>

        <div>
          <label>Fecha</label>
          <input
            type="date"
            value={nuevaReserva.fecha}
            onChange={(e) => setNuevaReserva({ ...nuevaReserva, fecha: e.target.value })}
            style={{ width: "100%", padding: "8px", marginBottom: "1rem" }}
          />
        </div>

        <div style={{ display: "flex", gap: "10px" }}>
          <div style={{ flex: 1 }}>
            <label>Hora de Inicio</label>
            <input
              type="time"
              value={nuevaReserva.horaInicio}
              onChange={(e) => setNuevaReserva({ ...nuevaReserva, horaInicio: e.target.value })}
              style={{ width: "100%", padding: "8px", marginBottom: "1rem" }}
            />
          </div>
          <div style={{ flex: 1 }}>
            <label>Hora de Fin</label>
            <input
              type="time"
              value={nuevaReserva.horaFin}
              onChange={(e) => setNuevaReserva({ ...nuevaReserva, horaFin: e.target.value })}
              style={{ width: "100%", padding: "8px", marginBottom: "1rem" }}
            />
          </div>
        </div>

        <button onClick={handleReserva} style={{ width: "100%", padding: "10px", backgroundColor: "#007BFF", color: "#fff", border: "none", borderRadius: "4px" }}>
          Reservar
        </button>
      </div>

      <h2 style={{ fontSize: "1.5rem", marginBottom: "1rem" }}>Reservas Existentes</h2>
      {reservas.length === 0 ? (
        <p>No hay reservas aún.</p>
      ) : (
        reservas.map((reserva, index) => (
          <div key={index} style={{ background: "#fff", padding: "1rem", borderRadius: "8px", marginBottom: "1rem", borderLeft: "4px solid #007BFF" }}>
            <p><strong>{reserva.nombre}</strong> – Villa {reserva.villa}</p>
            <p>{reserva.fecha}</p>
            <p>
              {reserva.horaInicio} – {reserva.horaFin}
            </p>
          </div>
        ))
      )}
    </div>
  );
}